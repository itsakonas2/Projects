﻿using Microsoft.AspNetCore.Mvc;
using GeoWebApplication1.Models;
using GeoWebApplication1.Interfaces;
using Microsoft.IdentityModel.Tokens;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace GeoWebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GeoDataController : ControllerBase
    {
        private readonly IGeoProxy _geoProxy;
        public GeoDataController(IGeoProxy geoProxy)=>_geoProxy = geoProxy;
        [HttpGet("{ip}")]
        public async Task<ActionResult<GeoData>> Get(string ip)
        {
            try
            {
                if (string.IsNullOrEmpty(ip))
                    return BadRequest();

                var response = await _geoProxy.GetIPAddressDataAsync(ip);
                return Ok(response);
            }
            catch { }
            {
                return Problem(statusCode: 500);
            }

        }
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] IEnumerable<string> addresses)
        {
            try
            {
                if (addresses.IsNullOrEmpty())
                    return BadRequest();

                var response = await _geoProxy.GetProgressEndpointAsync(addresses);
                return Ok(response);
            }
            catch { }
            {
                return Problem(statusCode: 500);
            }
        }

        [HttpGet("Progress/{batchCode}")]
        public async Task<ActionResult<ProgressData>> Get(Guid batchCode)
        {
            try
            {
                if(batchCode == Guid.Empty)
                    return BadRequest();

                var response = await _geoProxy.GetProgressDataAsync(batchCode);
                return Ok(response);
            }
            catch { }
            {
                return Problem(statusCode: 500);
            }
        }
    }
}
