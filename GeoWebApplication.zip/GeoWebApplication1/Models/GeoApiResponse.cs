﻿namespace GeoWebApplication1.Models
{

    public class GeoApiResponse
    {
        public Data data { get; set; }
    }

    public class Data
    {
        public string ip { get; set; }
        public object hostname { get; set; }
        public string type { get; set; }
        public Range_Type range_type { get; set; }
        public Connection connection { get; set; }
        public Location location { get; set; }
        public string[] tlds { get; set; }
        public Timezone timezone { get; set; }
        public Security security { get; set; }
        public Domains domains { get; set; }
    }

    public class Range_Type
    {
        public string type { get; set; }
        public string description { get; set; }
    }

    public class Connection
    {
        public int asn { get; set; }
        public string organization { get; set; }
        public string isp { get; set; }
        public string range { get; set; }
    }

    public class Location
    {
        public int geonames_id { get; set; }
        public float latitude { get; set; }
        public float longitude { get; set; }
        public string zip { get; set; }
        public Continent continent { get; set; }
        public Country country { get; set; }
        public City city { get; set; }
        public Region region { get; set; }
    }

    public class Continent
    {
        public string code { get; set; }
        public string name { get; set; }
        public string name_translated { get; set; }
        public int geonames_id { get; set; }
        public string wikidata_id { get; set; }
    }

    public class Country
    {
        public string alpha2 { get; set; }
        public string alpha3 { get; set; }
        public string[] calling_codes { get; set; }
        public Currency[] currencies { get; set; }
        public string emoji { get; set; }
        public string ioc { get; set; }
        public Language[] languages { get; set; }
        public string name { get; set; }
        public string name_translated { get; set; }
        public string[] timezones { get; set; }
        public bool is_in_european_union { get; set; }
        public string fips { get; set; }
        public int geonames_id { get; set; }
        public string hasc_id { get; set; }
        public string wikidata_id { get; set; }
    }

    public class Currency
    {
        public string symbol { get; set; }
        public string name { get; set; }
        public string symbol_native { get; set; }
        public int decimal_digits { get; set; }
        public int rounding { get; set; }
        public string code { get; set; }
        public string name_plural { get; set; }
        public string type { get; set; }
    }

    public class Language
    {
        public string name { get; set; }
        public string name_native { get; set; }
    }

    public class City
    {
        public object fips { get; set; }
        public object alpha2 { get; set; }
        public int geonames_id { get; set; }
        public object hasc_id { get; set; }
        public object wikidata_id { get; set; }
        public string name { get; set; }
        public string name_translated { get; set; }
    }

    public class Region
    {
        public string fips { get; set; }
        public string alpha2 { get; set; }
        public int geonames_id { get; set; }
        public string hasc_id { get; set; }
        public string wikidata_id { get; set; }
        public string name { get; set; }
        public string name_translated { get; set; }
    }

    public class Timezone
    {
        public string id { get; set; }
        public DateTime current_time { get; set; }
        public string code { get; set; }
        public bool is_daylight_saving { get; set; }
        public int gmt_offset { get; set; }
    }

    public class Security
    {
        public object is_anonymous { get; set; }
        public object is_datacenter { get; set; }
        public object is_vpn { get; set; }
        public object is_bot { get; set; }
        public object is_abuser { get; set; }
        public object is_known_attacker { get; set; }
        public object is_proxy { get; set; }
        public object is_spam { get; set; }
        public object is_tor { get; set; }
        public object proxy_type { get; set; }
        public object is_icloud_relay { get; set; }
        public object threat_score { get; set; }
    }

    public class Domains
    {
        public object count { get; set; }
        public object[] domains { get; set; }
    }

}
