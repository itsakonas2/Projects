﻿using System.Runtime.CompilerServices;

namespace GeoWebApplication1.Models
{
    public class GeoData
    {
        public string? IP { get; private set; }
        public string? CountryCode { get; private set; } //alpha2

        public string? CountryName { get; private set; }
        public string? Timezone { get; private set; }
        public double Latitude { get; private set; }
        public double Longitude { get; private set; }

        private GeoData(string ip, string countryCode, string countryName, string timezone, double latitude, double longtitude)
        {
            IP = ip;
            CountryCode = countryCode;
            CountryName = countryName;  
            Timezone = timezone;
            Latitude = latitude;
            Longitude = longtitude;
        }

        public static GeoData Create(string ip, string countryCode, string countryName, string timezone, double latitude, double longitude)
            => new GeoData(ip,countryCode,countryName,timezone,latitude,longitude);
    }
}
