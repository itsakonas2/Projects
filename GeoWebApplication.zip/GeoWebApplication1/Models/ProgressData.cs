﻿namespace GeoWebApplication1.Models
{
    public class ProgressData
    {
        public string ItemsCompleted { get; private set; }
        public string RemainingTimeToCompletion { get; private set; } //alpha2

        private ProgressData(string itemsCompleted, string remainingTimeToCompletion)
        {
            ItemsCompleted = itemsCompleted;
            RemainingTimeToCompletion = remainingTimeToCompletion;
        }

        public static ProgressData Create(string itemsCompleted, string remainingTimeToCompletion)
            => new ProgressData(itemsCompleted, remainingTimeToCompletion);
    }
}
