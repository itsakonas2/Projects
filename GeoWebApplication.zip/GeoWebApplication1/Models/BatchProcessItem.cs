﻿using System.ComponentModel.DataAnnotations;

namespace GeoWebApplication1.Models
{
    public class BatchProcessItem
    {
        [Key]
        public int Id { get; set; }
        public Guid Code { get; set; }
        public string? IPAddress { get; set; }
        public long ElapsedTime { get; set; }

        public int CurrentItem { get; set; }
        public int RemainingItems { get; set; }

        public BatchProcessItem() { }
    }
}
