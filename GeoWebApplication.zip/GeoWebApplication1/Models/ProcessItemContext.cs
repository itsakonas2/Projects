﻿using Microsoft.EntityFrameworkCore;

namespace GeoWebApplication1.Models
{
    public class BatchProcessItemContext : DbContext
    {
        public BatchProcessItemContext(DbContextOptions<BatchProcessItemContext> options)
        : base(options)
        {
        }

        public DbSet<BatchProcessItem> Items { get; set; }
    }
}
