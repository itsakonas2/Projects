using GeoWebApplication1;
using GeoWebApplication1.Interfaces;
using GeoWebApplication1.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHttpClient();
builder.Services.AddScoped<IGeoProxy, GeoProxy>();
builder.Services.AddDbContext<BatchProcessItemContext>(opt =>
    opt.UseSqlServer(@"Server=DESKTOP\SQLEXPRESS;Database=Test;Trusted_Connection=True;TrustServerCertificate=Yes;"),ServiceLifetime.Scoped);


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();

app.MapControllers();

app.Run();
