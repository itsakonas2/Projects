﻿using GeoWebApplication1.Interfaces;
using GeoWebApplication1.Models;
using Microsoft.Net.Http.Headers;
using System.Diagnostics;
using System.Text.Json;

namespace GeoWebApplication1
{
    public class GeoProxy : IGeoProxy
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IServiceScopeFactory _serviceScopeFactory;
        public GeoProxy(IConfiguration configuration, IHttpClientFactory httpClientFactory, BatchProcessItemContext dbContext, IServiceScopeFactory serviceScopeFactory)  
        {
         _configuration = configuration;
         _httpClientFactory = httpClientFactory; 
         _serviceScopeFactory = serviceScopeFactory;
        }

        public async Task<GeoData> GetIPAddressDataAsync(string ip)
        {
            try
            {
                var url = _configuration["APIUrl"];
                var apikey = _configuration["APIKey"];
                var request = string.Format(url, ip);
                var httpRequestMessage = new HttpRequestMessage(
                                         HttpMethod.Get,
                                         request)
                {
                    Headers =
                    {
                        { HeaderNames.Accept, "application/json" },
                        { "apikey", apikey}
                    }
                };

                var httpClient = _httpClientFactory.CreateClient();
                var httpResponseMessage = await httpClient.SendAsync(httpRequestMessage);

                if (httpResponseMessage.IsSuccessStatusCode)
                {
                    using var contentStream =
                        await httpResponseMessage.Content.ReadAsStreamAsync();

                    var apiResponse = await JsonSerializer.DeserializeAsync
                        <GeoApiResponse>(contentStream);

                    var geoData = GeoData.Create(ip, apiResponse.data.location.country.alpha2, apiResponse.data.location.country.name, apiResponse.data.timezone.code, apiResponse.data.location.latitude, apiResponse.data.location.longitude);

                    return geoData;
                }
                else
                {
                    throw new Exception(httpResponseMessage.StatusCode.ToString());
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<ProgressData> GetProgressDataAsync(Guid batchCode)
        {
            try
            {
                await using (var scope = _serviceScopeFactory.CreateAsyncScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<BatchProcessItemContext>();
                    var batchItems = context.Items.Where(i => i.Code == batchCode).ToList();
                    var doneItems = batchItems.Count;
                    var remaining = batchItems[doneItems - 1].RemainingItems;
                    var allItems = doneItems + remaining;
                    var completedItems = $"{doneItems.ToString()}/{allItems.ToString()}";
                    var totalTime = batchItems.Sum(i => i.ElapsedTime);
                    var estimatedCompletionTime = ((totalTime / doneItems) * remaining) / 1000;
                    var pd = ProgressData.Create(completedItems, estimatedCompletionTime.ToString());
                    return pd;
                }
            }
            catch (Exception ex) 
            {
                throw;
            }
        }

        public Task<string> GetProgressEndpointAsync(IEnumerable<string> addresses)
        {
            try
            {
                Guid batchCode = Guid.NewGuid();
                var url = _configuration["ProgressUrl"]+batchCode;
                Task.Run(()=>GetIPAddresses(addresses,batchCode));
                return Task.FromResult(url);
            }
            catch
            (Exception ex)
            {
                throw;
            }
        }

        protected async Task GetIPAddresses(IEnumerable<string> addresses,Guid batchCode)
        {
            try
            {
                await using (var scope = _serviceScopeFactory.CreateAsyncScope())
                {
                    int item = 1;
                    Stopwatch sw = new Stopwatch();

                    foreach (var ip in addresses)
                    {
                        sw.Start();
                        await GetIPAddressDataAsync(ip);
                        sw.Stop();
                        var elapsedTime = sw.ElapsedMilliseconds;

                        var context = scope.ServiceProvider.GetRequiredService<BatchProcessItemContext>();
                        context.Items.Add(new BatchProcessItem { Code = batchCode, IPAddress = ip, CurrentItem = item, ElapsedTime = elapsedTime, RemainingItems = addresses.Count() - item });

                        await context.SaveChangesAsync();
                        item++;
                    }
                }   
            }
            catch(Exception ex) 
            { throw; }
        }
    }
}
