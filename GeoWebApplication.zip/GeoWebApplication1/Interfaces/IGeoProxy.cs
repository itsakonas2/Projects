﻿using GeoWebApplication1.Models;

namespace GeoWebApplication1.Interfaces
{
    public interface IGeoProxy
    {
        public Task<GeoData> GetIPAddressDataAsync(string ip);

        public Task<string> GetProgressEndpointAsync(IEnumerable<string> addresses);

        public Task<ProgressData> GetProgressDataAsync(Guid batchCode);
    }
}
